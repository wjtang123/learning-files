# Ansible Demo 学习项目

覆盖所有核心知识点的完整实战 Demo，可直接在多台 Linux 虚拟机上运行。

---

## 项目结构

```
ansible-demo/
├── ansible.cfg                        # 配置文件（forks/pipelining/host_key_checking 等）
├── setup.sh                           # 一键初始化脚本
├── adhoc_cheatsheet.sh                # Ad-hoc 命令速查
│
├── inventory/
│   ├── hosts.ini                      # 主机清单（分组/组变量）
│   ├── group_vars/
│   │   └── webservers.yml             # 组变量文件（nginx配置/端口列表）
│   └── host_vars/
│       └── web-01.yml                 # 主机变量（覆盖组变量示例）
│
├── vault/
│   └── secrets.yml                    # Vault 加密敏感变量
│
├── library/
│   └── system_info.py                 # 自定义 Python 模块
│
├── playbooks/
│   ├── site.yml                       # 主入口：多 play 全量部署
│   ├── rolling_update.yml             # 滚动更新（serial/delegate_to）
│   ├── variable_priority_demo.yml     # 变量优先级完整演示
│   └── custom_module_demo.yml         # 自定义模块使用演示
│
└── roles/
    ├── webserver/                     # Web 服务器 Role
    │   ├── defaults/main.yml          # 默认变量（最低优先级）
    │   ├── tasks/main.yml             # 核心任务（when/loop/block/register）
    │   ├── handlers/main.yml          # handlers（restart/reload nginx）
    │   ├── templates/
    │   │   ├── nginx.conf.j2          # Jinja2 模板（条件/循环/过滤器）
    │   │   └── index.html.j2          # 展示 facts + 变量的静态页
    │   └── files/
    │       └── demo.conf              # copy 模块用的静态文件
    ├── database/                      # 数据库 Role
    │   ├── defaults/main.yml
    │   ├── tasks/main.yml             # MySQL安装/changed_when/failed_when
    │   └── handlers/main.yml
    └── monitor/                       # 监控 Role
        ├── defaults/main.yml
        └── tasks/main.yml             # async异步/until轮询/set_fact
```

---

## 快速开始

### 第一步：修改 Inventory

编辑 `inventory/hosts.ini`，将 IP 替换为你的虚拟机真实 IP：

```ini
[webservers]
web-01 ansible_host=你的IP1
web-02 ansible_host=你的IP2

[databases]
db-01 ansible_host=你的IP3
```

如果只有一台机器，可以让所有组都指向同一个 IP：

```ini
[webservers]
node-01 ansible_host=192.168.56.10

[databases]
node-01 ansible_host=192.168.56.10

[monitor]
node-01 ansible_host=192.168.56.10
```

### 第二步：初始化环境

```bash
bash setup.sh
```

按照脚本输出的提示，在每台被控节点上创建 ansible 用户并推送 SSH 公钥。

### 第三步：验证连通性

```bash
ansible all -i inventory/hosts.ini -m ping
```

所有主机返回 `pong` 即表示配置成功。

---

## 运行各个演示

### 完整部署（site.yml）

```bash
# 跳过 Vault（初次测试推荐）
ansible-playbook -i inventory/hosts.ini playbooks/site.yml \
  -e "skip_vault=true"

# 完整运行（包含 Vault 加密变量）
ansible-vault encrypt vault/secrets.yml   # 先加密
ansible-playbook -i inventory/hosts.ini playbooks/site.yml --ask-vault-pass
```

### 变量优先级演示

```bash
# 正常运行，color 来自 Playbook vars
ansible-playbook -i inventory/hosts.ini playbooks/variable_priority_demo.yml

# 用命令行 -e 覆盖变量（最高优先级）
ansible-playbook -i inventory/hosts.ini playbooks/variable_priority_demo.yml \
  -e "color=red nginx_port=8080"
```

### 自定义模块演示

```bash
ansible-playbook -i inventory/hosts.ini playbooks/custom_module_demo.yml
```

### 滚动更新演示

```bash
# 每次只更新 1 台 webserver
ansible-playbook -i inventory/hosts.ini playbooks/rolling_update.yml
```

### Ad-hoc 命令速查

```bash
bash adhoc_cheatsheet.sh          # 打印所有命令示例

# 实际执行（举例）：
ansible all -i inventory/hosts.ini -m ping
ansible all -i inventory/hosts.ini -m setup -a 'filter=ansible_distribution*'
ansible webservers -i inventory/hosts.ini -b -m service -a 'name=nginx state=restarted'
```

---

## 知识点覆盖对照表

| 知识点 | 对应文件 |
|---|---|
| Inventory 分组/组变量/主机变量 | `inventory/hosts.ini`, `group_vars/`, `host_vars/` |
| ansible.cfg 配置（forks/pipelining/timeout）| `ansible.cfg` |
| Ad-hoc 命令 | `adhoc_cheatsheet.sh` |
| Playbook 结构（play/tasks/handlers）| `playbooks/site.yml` |
| 常用模块（apt/service/file/copy/template/user/cron）| `roles/webserver/tasks/main.yml` |
| when 条件判断 | `roles/webserver/tasks/main.yml` |
| loop 循环 | `roles/webserver/tasks/main.yml` |
| register 注册变量 | `roles/webserver/tasks/main.yml`, `variable_priority_demo.yml` |
| block/rescue/always | `roles/webserver/tasks/main.yml` |
| changed_when / failed_when / ignore_errors | `roles/database/tasks/main.yml` |
| Jinja2 模板（条件/循环/过滤器）| `roles/webserver/templates/nginx.conf.j2` |
| ansible_facts 系统信息 | `roles/webserver/templates/index.html.j2` |
| 变量优先级（全部 6 种）| `playbooks/variable_priority_demo.yml` |
| Role 目录结构 | `roles/webserver/` |
| defaults vs vars | `roles/webserver/defaults/main.yml` |
| Vault 加密 | `vault/secrets.yml` |
| async 异步 + until 轮询 | `roles/monitor/tasks/main.yml` |
| set_fact 动态变量 | `roles/monitor/tasks/main.yml` |
| serial 滚动更新 | `playbooks/rolling_update.yml` |
| delegate_to 委托执行 | `playbooks/rolling_update.yml` |
| 自定义 Python 模块 | `library/system_info.py`, `custom_module_demo.yml` |
| pipelining / forks 性能优化 | `ansible.cfg` |
| facts 缓存 | `ansible.cfg` |

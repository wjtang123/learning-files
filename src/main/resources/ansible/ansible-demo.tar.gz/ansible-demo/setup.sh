#!/bin/bash
# setup.sh - 一键初始化控制节点环境
# 在控制节点（你的本机或其中一台VM）上运行此脚本
# 使用方法：bash setup.sh

set -e
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

info()  { echo -e "${GREEN}[INFO]${NC}  $1"; }
warn()  { echo -e "${YELLOW}[WARN]${NC}  $1"; }
error() { echo -e "${RED}[ERROR]${NC} $1"; exit 1; }

echo ""
echo "=================================================="
echo "  Ansible Demo - 环境初始化脚本"
echo "=================================================="
echo ""

# ── Step 1：安装 Ansible ──────────────────────────────
info "Step 1: 安装 Ansible..."
if command -v ansible &>/dev/null; then
    info "Ansible 已安装：$(ansible --version | head -1)"
else
    if command -v apt &>/dev/null; then
        sudo apt update -q && sudo apt install -y ansible python3-pip
    elif command -v yum &>/dev/null; then
        sudo yum install -y ansible python3-pip
    else
        pip3 install ansible --user
    fi
    info "Ansible 安装完成：$(ansible --version | head -1)"
fi

# ── Step 2：生成 SSH 密钥 ──────────────────────────────
info "Step 2: 生成 Ansible 专用 SSH 密钥..."
KEY_PATH="$HOME/.ssh/ansible_demo_rsa"
if [ -f "$KEY_PATH" ]; then
    warn "SSH 密钥已存在：$KEY_PATH（跳过生成）"
else
    ssh-keygen -t ed25519 -C "ansible-demo" -f "$KEY_PATH" -N ""
    info "SSH 密钥已生成：$KEY_PATH"
fi

echo ""
echo "=================================================="
echo "  接下来需要你手动完成以下步骤："
echo "=================================================="
echo ""
echo "【Step 3】将公钥推送到所有被控节点："
echo ""
echo "  # 编辑 inventory/hosts.ini，填入你的真实 IP"
echo ""
echo "  # 然后逐台推送公钥（需要输入目标机器的密码）："
echo "  ssh-copy-id -i ~/.ssh/ansible_demo_rsa.pub ansible@192.168.56.11"
echo "  ssh-copy-id -i ~/.ssh/ansible_demo_rsa.pub ansible@192.168.56.12"
echo "  ssh-copy-id -i ~/.ssh/ansible_demo_rsa.pub ansible@192.168.56.21"
echo "  ssh-copy-id -i ~/.ssh/ansible_demo_rsa.pub ansible@192.168.56.31"
echo ""
echo "【Step 4】在每台被控节点上创建 ansible 用户（以 root 身份）："
echo ""
echo "  useradd -m -s /bin/bash ansible"
echo "  echo 'ansible ALL=(ALL) NOPASSWD:ALL' >> /etc/sudoers.d/ansible"
echo "  chmod 440 /etc/sudoers.d/ansible"
echo ""
echo "【Step 5】测试连通性："
echo ""
echo "  ansible all -i inventory/hosts.ini -m ping"
echo ""
echo "【Step 6】执行完整 Demo："
echo ""
echo "  # 初始化 Vault 密码（可选）"
echo "  ansible-vault encrypt vault/secrets.yml"
echo ""
echo "  # 运行完整部署"
echo "  ansible-playbook -i inventory/hosts.ini playbooks/site.yml --ask-vault-pass"
echo ""
echo "  # 或跳过 Vault（仅测试基础功能）"
echo "  ansible-playbook -i inventory/hosts.ini playbooks/site.yml --skip-tags vault"
echo ""
echo "  # 变量优先级演示"
echo "  ansible-playbook -i inventory/hosts.ini playbooks/variable_priority_demo.yml -e 'color=red'"
echo ""
echo "  # 自定义模块演示"
echo "  ansible-playbook -i inventory/hosts.ini playbooks/custom_module_demo.yml"
echo ""
echo "  # 滚动更新演示（只对 webservers）"
echo "  ansible-playbook -i inventory/hosts.ini playbooks/rolling_update.yml"
echo ""
echo "  # 查看 Ad-hoc 命令速查"
echo "  bash adhoc_cheatsheet.sh"
echo ""
echo "=================================================="

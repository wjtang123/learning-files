#!/usr/bin/python
# -*- coding: utf-8 -*-
# library/system_info.py
# 知识点：自定义 Ansible 模块，AnsibleModule 类，exit_json / fail_json

from ansible.module_utils.basic import AnsibleModule
import os
import platform

DOCUMENTATION = r'''
---
module: system_info
short_description: 收集自定义系统信息
description:
  - 演示如何编写自定义 Ansible 模块
  - 收集指定目录的磁盘使用情况和系统信息
options:
  path:
    description: 要检查的目录路径
    required: true
    type: str
  warn_threshold:
    description: 磁盘使用率告警阈值（百分比）
    required: false
    type: int
    default: 80
'''

def run_module():
    # 1. 定义模块参数
    module_args = dict(
        path=dict(type='str', required=True),
        warn_threshold=dict(type='int', required=False, default=80),
    )

    # 2. 初始化
    module = AnsibleModule(
        argument_spec=module_args,
        supports_check_mode=True
    )

    path = module.params['path']
    warn_threshold = module.params['warn_threshold']

    # 3. check mode 支持
    if module.check_mode:
        module.exit_json(changed=False, msg="Check mode: 不执行实际操作")

    # 4. 参数校验
    if not os.path.exists(path):
        module.fail_json(msg=f"路径不存在: {path}")

    # 5. 执行逻辑：获取磁盘使用情况
    try:
        stat = os.statvfs(path)
        total   = stat.f_blocks * stat.f_frsize
        free    = stat.f_bfree  * stat.f_frsize
        used    = total - free
        use_pct = round(used / total * 100, 1) if total > 0 else 0

        result = dict(
            changed=False,
            path=path,
            total_gb=round(total / 1024**3, 2),
            used_gb=round(used  / 1024**3, 2),
            free_gb=round(free  / 1024**3, 2),
            use_percent=use_pct,
            hostname=platform.node(),
            python_version=platform.python_version(),
            warning=(use_pct >= warn_threshold),
            warn_threshold=warn_threshold,
        )

        # 超过阈值时添加警告信息（但不 fail）
        if result['warning']:
            result['msg'] = f"磁盘使用率 {use_pct}% 超过告警阈值 {warn_threshold}%"
        else:
            result['msg'] = f"磁盘使用率 {use_pct}%，正常"

    except Exception as e:
        module.fail_json(msg=f"获取磁盘信息失败: {str(e)}")

    # 6. 返回结果
    module.exit_json(**result)


def main():
    run_module()


if __name__ == '__main__':
    main()
